export class UserUpdateDto{
    name: string;
    description: string;
    dateAdded: Date;
}